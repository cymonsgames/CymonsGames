#ifndef __TILES_H
#define __TILES_H

#define WALL 0
#define GRAVEL 1
#define WATER 2
#define OUTERWALL 3
#define HOLE 4
#define SHOP 5
#define PORTAL 6

#endif

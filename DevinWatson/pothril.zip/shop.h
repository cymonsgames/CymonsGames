#ifndef __SHOP_H
#define __SHOP_H

#include "coord.h"

#endif

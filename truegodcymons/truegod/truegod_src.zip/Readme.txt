Stones of Chaos: The True God 7 Day Roguelike by James E. Ward (idontexist)

Press '?' ingame for help


All parts of program and its source are liscenced under GNU (included) except for Mersene Twister (liscence included)

Copyright 2009 James E. Ward
#ifndef MISC_H_INCLUDED
#define MISC_H_INCLUDED
void init ();
void putmsg(char newmess[]);
double range(int y1,int x1,int y2, int x2);
int dice(int numDice,int sideDice,int bonus);
void help();

#endif // MISC_H_INCLUDED

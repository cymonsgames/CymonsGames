Rover Wars, there can be only one. With each opponent you absorb you add to your total mass. However you can just as easily be absorbed by someone larger. The last blob left is the winner.

Rover Wars is a competitive game for 3 players. At the main menu you can choose to let the computer control any of the opponents. Then just into the game. Absorb blobs smaller than you, avoid balls larger than you. The last of the 3 player blobs left is the winner. Rounds tend to be short, not lasting more than a minute. A good enhancement would be some sort of score table between games to keep track of who�s won more games and declare a winner after a number of wins.

Rover Wars was written by Joe Larson.

This program and its code is was featured on Cymon's Game.

If you like this program, are interested in programming or just love games please visit:
	http://www.cymonsgames.com
for free source code, tutorials, resoruces, and a new game every week.
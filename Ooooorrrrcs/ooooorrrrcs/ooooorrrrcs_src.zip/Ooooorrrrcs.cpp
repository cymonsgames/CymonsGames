#include "curses.h"
#include <stdlib.h>
#include <time.h>
#define S 40
#define A mvprintw
#define B rand()
#define L level[x][y]
#define F for(x=0;x<S;++x)
#define G for(y=0;y<S;++y)
#define H (y,x,"%c",L)
void main(){srand(time(NULL));initscr();resize_term(S,60);curs_set(0);noecho();
int h=100,t=0,p=2,x,y,a=20,b=20,level[S+1][S];char*m="lost";
F f:G L=rand()%3?32:219;if(t++==0)level[19][20]=62;x=1;G L=rand()%2?L :79+(rand()%2)*0x20;x=39;
G L=rand()%150?L:rand()%3?63:65+rand()%5;F G L=level[x+1][y];x=a,y=b;if (!(L &8)){L--;if(L==64){p++;L=63;}}
a=x,b=y;if(L==63)a++,h+=20,L=32;if(h>100)h=100;while(L>63)a--,x=a;F	G mvaddch(y,x,L); mvaddch(b,a,'@');
A(20,50,"HP %d  ",h);A(21,50,"MP %d  ",p);A(22,50,"Turn %d",t);refresh();switch(getch())
{case'8':a--;case'9':b--;break;case'2':a--;case'3':b++;break;case'p':if(p>0)a+=p,p=0;}
if(a<1||b<0||b>=S||h<=0)goto e;if (a>=S-1){m="won";goto e;}h--,x=39;goto f;e:A(20,22,"You %s in %d turns!",m,t);refresh();getch();}